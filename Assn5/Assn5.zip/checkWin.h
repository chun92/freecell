/***
 *
 * winCheck.h
 *
 * check winning condition
 *
 */

#ifndef CHECK_WIN_H
#define CHECK_WIN_H

#include "board.h"
int checkWin(Stack** homecell);
#endif