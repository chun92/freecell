/***
 *
 * console.h
 *
 * Console I/O format
 *
 */

#ifndef CONSOLE_H
#define CONSOLE_H

#include "card.h"

void printConsoleFormat(Card* card);

#endif