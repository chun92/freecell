/***
 *
 * print.h
 *
 * Print the game status on cosonle.
 *
 */

#ifndef PRINT_H
#define PRINT_H

#include "board.h"

void print(Stack** line, Stack** freecell, Stack** homecell);

#endif